package packager;

public class ExitLoop {
	public static void print() {
		System.out.println("You chose option 5...");
		System.out.println("Closing the program");
	}

}
