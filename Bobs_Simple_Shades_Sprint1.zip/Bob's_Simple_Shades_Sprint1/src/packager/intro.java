package packager;
//Class intro print the menu to the user
public class intro {
	public static void print() {
		System.out.println("**********************************************");
		// System.out.println("");
		System.out.println("Bob's Simple Shades");
		// System.out.println("");
		System.out.println("**********************************************");
		// System.out.println("");
		System.out.println("1. Create a new sales record.");
		System.out.println("2. Show a record.");
		System.out.println("3. Exit");
		System.out.print("Enter your option [1 - 3]: ");
	}

}
